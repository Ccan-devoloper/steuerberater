(() => {
  'use strict';

  const data = window.STB_DATA;
  if (!data) {
    console.error('Lerndaten konnten nicht geladen werden.');
    return;
  }

  const STORAGE_KEY = 'stb-bilanzen-state-v1';
  const validViews = ['dashboard', 'lernen', 'schema', 'training', 'lernplan'];
  const defaultState = {
    completed: [],
    planCompleted: [],
    theme: null,
    bestQuiz: 0
  };

  let state = loadState();
  let activeArea = 'alle';
  let searchTerm = '';
  let currentTopicId = null;
  let quizState = null;
  let toastTimer = null;

  const els = {
    html: document.documentElement,
    views: [...document.querySelectorAll('[data-view]')],
    navLinks: [...document.querySelectorAll('[data-view-link]')],
    sideLinks: [...document.querySelectorAll('.side-link')],
    globalSearch: document.querySelector('#global-search'),
    themeToggle: document.querySelector('#theme-toggle'),
    topicCount: document.querySelector('#topic-count'),
    totalCount: document.querySelector('#total-count'),
    completedCount: document.querySelector('#completed-count'),
    progressPercent: document.querySelector('#progress-percent'),
    progressRing: document.querySelector('#progress-ring'),
    progressMessage: document.querySelector('#progress-message'),
    areaOverview: document.querySelector('#area-overview'),
    continueLearning: document.querySelector('#continue-learning'),
    moduleList: document.querySelector('#module-list'),
    moduleEmpty: document.querySelector('#module-empty'),
    filteredCount: document.querySelector('#filtered-count'),
    filterChips: [...document.querySelectorAll('[data-area-filter]')],
    schemaTabs: [...document.querySelectorAll('[data-schema-step]')],
    schemaDetail: document.querySelector('#schema-detail'),
    writingTemplates: document.querySelector('#writing-templates'),
    topicDialog: document.querySelector('#topic-dialog'),
    dialogContent: document.querySelector('#dialog-content'),
    dialogClose: document.querySelector('#dialog-close'),
    placeholderDialog: document.querySelector('#placeholder-dialog'),
    placeholderClose: document.querySelector('#placeholder-close'),
    placeholderOk: document.querySelector('#placeholder-ok'),
    resetProgress: document.querySelector('#reset-progress'),
    toast: document.querySelector('#toast'),
    planList: document.querySelector('#plan-list'),
    planProgressCount: document.querySelector('#plan-progress-count'),
    pointsInput: document.querySelector('#points-input'),
    minutesResult: document.querySelector('#minutes-result'),
    clockResult: document.querySelector('#clock-result'),
    startQuiz: document.querySelector('#start-quiz'),
    quizStart: document.querySelector('#quiz-start'),
    quizRun: document.querySelector('#quiz-run'),
    quizResult: document.querySelector('#quiz-result'),
    quizProgressLabel: document.querySelector('#quiz-progress-label'),
    quizScoreLabel: document.querySelector('#quiz-score-label'),
    quizProgressBar: document.querySelector('#quiz-progress-bar'),
    quizQuestion: document.querySelector('#quiz-question'),
    quizOptions: document.querySelector('#quiz-options'),
    quizFeedback: document.querySelector('#quiz-feedback'),
    nextQuestion: document.querySelector('#next-question')
  };

  function loadState() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
      return { ...defaultState, ...(saved || {}) };
    } catch {
      return { ...defaultState };
    }
  }

  function saveState() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      // Die App bleibt auch in restriktiven Browsermodi nutzbar; nur die Persistenz entfällt.
    }
  }

  function escapeHtml(value = '') {
    return String(value)
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  function normalize(value = '') {
    return String(value)
      .toLocaleLowerCase('de-DE')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '');
  }

  function showToast(message) {
    clearTimeout(toastTimer);
    els.toast.textContent = message;
    els.toast.classList.add('is-visible');
    toastTimer = setTimeout(() => els.toast.classList.remove('is-visible'), 2200);
  }

  function applyTheme() {
    const systemDark = window.matchMedia?.('(prefers-color-scheme: dark)').matches;
    const theme = state.theme || (systemDark ? 'dark' : 'light');
    els.html.dataset.theme = theme;
    els.themeToggle.setAttribute('aria-label', theme === 'dark' ? 'Helle Darstellung aktivieren' : 'Dunkle Darstellung aktivieren');
  }

  function setView(view, updateHash = true) {
    const target = validViews.includes(view) ? view : 'dashboard';
    els.views.forEach(section => {
      const visible = section.dataset.view === target;
      section.hidden = !visible;
      section.classList.toggle('is-visible', visible);
    });
    els.sideLinks.forEach(link => {
      link.classList.toggle('is-active', link.dataset.viewLink === target);
    });
    if (updateHash && location.hash !== `#${target}`) {
      history.pushState(null, '', `#${target}`);
    }
    document.title = `${viewTitle(target)} · StB Examenscampus`;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function viewTitle(view) {
    return {
      dashboard: 'Übersicht Bilanzen',
      lernen: 'Lernmodule Bilanzen',
      schema: 'Universalschema',
      training: 'Prüfungstraining',
      lernplan: '8-Wochen-Plan'
    }[view] || 'StB Examenscampus';
  }

  function renderDashboard() {
    const total = data.modules.length;
    const completed = state.completed.filter(id => data.modules.some(module => module.id === id)).length;
    const percent = total ? Math.round((completed / total) * 100) : 0;

    els.topicCount.textContent = total;
    els.totalCount.textContent = total;
    els.completedCount.textContent = completed;
    els.progressPercent.textContent = `${percent} %`;
    els.progressRing.style.setProperty('--progress', `${percent * 3.6}deg`);
    els.progressMessage.textContent = progressMessage(percent);

    els.areaOverview.innerHTML = data.areas.map(area => {
      const modules = data.modules.filter(module => module.area === area.name);
      const done = modules.filter(module => state.completed.includes(module.id)).length;
      return `
        <article class="area-card card" style="--area-color:${escapeHtml(area.color)}">
          <div class="area-card-top">
            <span class="area-number">${escapeHtml(area.number)}</span>
            <span class="tag">${done}/${modules.length} gelernt</span>
          </div>
          <h3>${escapeHtml(area.name)}</h3>
          <p>${escapeHtml(area.description)}</p>
          <div class="area-stats">
            <span><strong>${modules.length}</strong><small>Module</small></span>
            <span><strong>${escapeHtml(area.typical)}</strong><small>typisch</small></span>
          </div>
          <button class="area-open" type="button" data-open-area="${escapeHtml(area.name)}">Themen öffnen →</button>
        </article>`;
    }).join('');

    const nextModule = data.modules.find(module => !state.completed.includes(module.id)) || data.modules[0];
    const allDone = completed === total;
    els.continueLearning.innerHTML = allDone ? `
      <div class="continue-topic">
        <span class="topic-icon">✓</span>
        <div><strong>Alle Module abgeschlossen</strong><small>Nutze jetzt Training und Wiederholungsplan.</small></div>
        <a class="button button-primary" href="#training" data-view-link="training">Trainieren</a>
      </div>` : `
      <div class="continue-topic">
        <span class="topic-icon">${escapeHtml(String(data.modules.indexOf(nextModule) + 1).padStart(2, '0'))}</span>
        <div><strong>${escapeHtml(nextModule.title)}</strong><small>${escapeHtml(nextModule.area)} · ${escapeHtml(nextModule.cluster)}</small></div>
        <button class="button button-primary" type="button" data-open-topic="${escapeHtml(nextModule.id)}">Öffnen</button>
      </div>`;
  }

  function progressMessage(percent) {
    if (percent === 100) return 'Starker Stand. Jetzt Wiederholung und Klausurtakt trainieren.';
    if (percent >= 75) return 'Die Zielgerade: Lücken schließen und Technik automatisieren.';
    if (percent >= 50) return 'Halbzeit. Personengesellschaft und KapGes gezielt verknüpfen.';
    if (percent >= 25) return 'Guter Start. Baue jetzt die wiederkehrenden Schemata aus.';
    return 'Starte mit den Grundlagen des Einzelunternehmens.';
  }

  function moduleMatches(module) {
    const areaMatches = activeArea === 'alle' || module.area === activeArea;
    if (!areaMatches) return false;
    if (!searchTerm.trim()) return true;
    const haystack = normalize([
      module.title,
      module.area,
      module.cluster,
      module.summary,
      module.frequency,
      module.laws.join(' '),
      module.schema.join(' '),
      module.trap,
      module.mnemonic
    ].join(' '));
    return haystack.includes(normalize(searchTerm.trim()));
  }

  function renderModules() {
    const filtered = data.modules.filter(moduleMatches);
    els.filteredCount.textContent = filtered.length;
    els.moduleEmpty.hidden = filtered.length > 0;
    els.moduleList.innerHTML = filtered.map(module => {
      const complete = state.completed.includes(module.id);
      const priorityClass = module.priority === 'hoch' ? 'priority-high' : 'priority-medium';
      return `
        <article class="module-card ${complete ? 'is-complete' : ''}" data-module-id="${escapeHtml(module.id)}">
          <input class="module-check" type="checkbox" ${complete ? 'checked' : ''} aria-label="${escapeHtml(module.title)} als gelernt markieren" data-complete-topic="${escapeHtml(module.id)}">
          <div class="module-main">
            <div class="module-title-row">
              <h3>${escapeHtml(module.title)}</h3>
              <span class="tag ${priorityClass}">${escapeHtml(module.priority)}e Priorität</span>
              <span class="tag">${escapeHtml(module.frequency)}</span>
            </div>
            <p>${escapeHtml(module.summary)}</p>
            <div class="module-tags">
              <span class="tag area">${escapeHtml(module.area)}</span>
              <span class="tag">${escapeHtml(module.cluster)}</span>
              ${module.laws.slice(0, 3).map(law => `<span class="tag">${escapeHtml(law)}</span>`).join('')}
            </div>
          </div>
          <button class="module-open" type="button" data-open-topic="${escapeHtml(module.id)}">Details →</button>
        </article>`;
    }).join('');
  }

  function openTopic(id) {
    const module = data.modules.find(item => item.id === id);
    if (!module) return;
    currentTopicId = id;
    const complete = state.completed.includes(id);
    els.dialogContent.innerHTML = `
      <div class="dialog-inner">
        <span class="eyebrow">${escapeHtml(module.area)} · ${escapeHtml(module.cluster)}</span>
        <h2 id="dialog-title">${escapeHtml(module.title)}</h2>
        <p class="dialog-summary">${escapeHtml(module.summary)}</p>
        <div class="dialog-tags">
          <span class="tag ${module.priority === 'hoch' ? 'priority-high' : 'priority-medium'}">Priorität ${escapeHtml(module.priority)}</span>
          <span class="tag">Treffer: ${escapeHtml(module.frequency)}</span>
          ${module.laws.map(law => `<span class="tag area">${escapeHtml(law)}</span>`).join('')}
        </div>
        <section class="dialog-section">
          <h3>Prüfschema</h3>
          <ol class="dialog-list">${module.schema.map(step => `<li>${escapeHtml(step)}</li>`).join('')}</ol>
        </section>
        <section class="dialog-section trap-box">
          <h3>Klausurfalle</h3>
          <p>${escapeHtml(module.trap)}</p>
        </section>
        <section class="dialog-section mnemonic-box">
          <h3>Merkhilfe</h3>
          <p>${escapeHtml(module.mnemonic)}</p>
        </section>
        <button class="button ${complete ? 'button-secondary' : 'button-primary'} dialog-complete" type="button" data-dialog-complete="${escapeHtml(module.id)}">
          ${complete ? 'Als noch nicht sicher markieren' : 'Als gelernt markieren'}
        </button>
      </div>`;
    if (!els.topicDialog.open) {
      if (typeof els.topicDialog.showModal === 'function') els.topicDialog.showModal();
      else els.topicDialog.setAttribute('open', '');
    }
  }

  function closeDialog(dialog) {
    if (dialog.open && typeof dialog.close === 'function') dialog.close();
    else dialog.removeAttribute('open');
  }

  function toggleTopic(id) {
    const completed = new Set(state.completed);
    if (completed.has(id)) completed.delete(id);
    else completed.add(id);
    state.completed = [...completed];
    saveState();
    renderDashboard();
    renderModules();
    if (els.topicDialog.open && currentTopicId === id) openTopic(id);
  }

  function renderSchemaStep(index = 0) {
    const step = data.schemaSteps[index];
    els.schemaTabs.forEach((tab, tabIndex) => {
      const active = tabIndex === index;
      tab.classList.toggle('is-active', active);
      tab.setAttribute('aria-selected', String(active));
    });
    els.schemaDetail.innerHTML = `
      <div class="schema-detail-grid">
        <div class="schema-stage">
          <div class="stage-number">${String(index + 1).padStart(2, '0')}</div>
          <span class="eyebrow">${escapeHtml(step.subtitle)}</span>
          <h2>${escapeHtml(step.title)}</h2>
          <p>${escapeHtml(step.description)}</p>
        </div>
        <div>
          <ul class="schema-checklist">${step.checks.map(check => `<li>${escapeHtml(check)}</li>`).join('')}</ul>
          <div class="schema-cue"><strong>Punktesicherung:</strong> ${escapeHtml(step.cue)}</div>
        </div>
      </div>`;
  }

  function renderTemplates() {
    els.writingTemplates.innerHTML = data.templates.map((template, index) => `
      <article class="template-card">
        <span class="eyebrow">${escapeHtml(template.label)}</span>
        <p>${escapeHtml(template.text)}</p>
        <button class="copy-button" type="button" data-copy-template="${index}" aria-label="Formulierung kopieren" title="Kopieren">
          <svg aria-hidden="true" viewBox="0 0 24 24"><path d="M9 8h10v12H9zM5 16H4V4h10v1"/></svg>
        </button>
      </article>`).join('');
  }

  async function copyTemplate(index) {
    const text = data.templates[index]?.text;
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
      showToast('Formulierung kopiert.');
    } catch {
      const textarea = document.createElement('textarea');
      textarea.value = text;
      document.body.append(textarea);
      textarea.select();
      document.execCommand('copy');
      textarea.remove();
      showToast('Formulierung kopiert.');
    }
  }

  function renderPlan() {
    els.planList.innerHTML = data.plan.map((item, index) => {
      const complete = state.planCompleted.includes(index);
      return `
        <article class="plan-item ${complete ? 'is-complete' : ''}">
          <input type="checkbox" ${complete ? 'checked' : ''} data-plan-index="${index}" aria-label="Woche ${escapeHtml(item.weeks)} abschließen">
          <span class="plan-week">Woche ${escapeHtml(item.weeks)}</span>
          <div><h3>${escapeHtml(item.title)}</h3><p>${escapeHtml(item.text)}</p></div>
          <span class="plan-klausuren">${escapeHtml(item.exams)}</span>
        </article>`;
    }).join('');
    els.planProgressCount.textContent = `${state.planCompleted.length}/${data.plan.length}`;
  }

  function togglePlan(index) {
    const completed = new Set(state.planCompleted);
    if (completed.has(index)) completed.delete(index);
    else completed.add(index);
    state.planCompleted = [...completed].sort((a, b) => a - b);
    saveState();
    renderPlan();
  }

  function updateCalculator() {
    const points = Math.min(100, Math.max(0, Number(els.pointsInput.value) || 0));
    const minutes = Math.round(points * 3.6);
    const hours = Math.floor(minutes / 60);
    const remaining = minutes % 60;
    els.minutesResult.textContent = minutes;
    els.clockResult.textContent = hours
      ? `entspricht ${hours} Std.${remaining ? ` ${remaining} Min.` : ''}`
      : `entspricht ${remaining} Min.`;
  }

  function shuffled(items) {
    return [...items]
      .map(value => ({ value, sort: Math.random() }))
      .sort((a, b) => a.sort - b.sort)
      .map(item => item.value);
  }

  function startQuiz() {
    quizState = {
      questions: shuffled(data.quiz).slice(0, 10),
      index: 0,
      score: 0,
      answered: false
    };
    els.quizStart.hidden = true;
    els.quizResult.hidden = true;
    els.quizRun.hidden = false;
    renderQuestion();
  }

  function renderQuestion() {
    const question = quizState.questions[quizState.index];
    quizState.answered = false;
    els.quizProgressLabel.textContent = `Frage ${quizState.index + 1} von ${quizState.questions.length}`;
    els.quizScoreLabel.textContent = `${quizState.score} richtig`;
    els.quizProgressBar.style.width = `${((quizState.index + 1) / quizState.questions.length) * 100}%`;
    els.quizQuestion.textContent = question.q;
    els.quizOptions.innerHTML = question.choices.map((choice, index) => `
      <button class="quiz-option" type="button" data-quiz-choice="${index}">
        <span>${String.fromCharCode(65 + index)}</span>${escapeHtml(choice)}
      </button>`).join('');
    els.quizFeedback.hidden = true;
    els.quizFeedback.className = 'quiz-feedback';
    els.nextQuestion.hidden = true;
  }

  function answerQuiz(choiceIndex) {
    if (!quizState || quizState.answered) return;
    quizState.answered = true;
    const question = quizState.questions[quizState.index];
    const correct = choiceIndex === question.answer;
    if (correct) quizState.score += 1;

    [...els.quizOptions.querySelectorAll('.quiz-option')].forEach((button, index) => {
      button.disabled = true;
      if (index === question.answer) button.classList.add('is-correct');
      if (index === choiceIndex && !correct) button.classList.add('is-wrong');
    });

    els.quizScoreLabel.textContent = `${quizState.score} richtig`;
    els.quizFeedback.classList.add(correct ? 'correct' : 'wrong');
    els.quizFeedback.innerHTML = `<strong>${correct ? 'Richtig.' : 'Noch nicht.'}</strong><p>${escapeHtml(question.explanation)}</p>`;
    els.quizFeedback.hidden = false;
    els.nextQuestion.textContent = quizState.index === quizState.questions.length - 1 ? 'Ergebnis anzeigen' : 'Nächste Frage';
    els.nextQuestion.hidden = false;
  }

  function nextQuestion() {
    if (!quizState?.answered) return;
    if (quizState.index < quizState.questions.length - 1) {
      quizState.index += 1;
      renderQuestion();
    } else {
      finishQuiz();
    }
  }

  function finishQuiz() {
    const score = quizState.score;
    const total = quizState.questions.length;
    state.bestQuiz = Math.max(state.bestQuiz || 0, score);
    saveState();
    const message = score >= 9
      ? 'Sehr prüfungsfest – halte den Takt mit Originalklausuren.'
      : score >= 7
        ? 'Gute Basis. Wiederhole die Fehler und starte erneut.'
        : score >= 5
          ? 'Solider Anfang. Nutze die Lernmodule für die offenen Schemata.'
          : 'Zurück zu den Kernmodulen: Ansatz, Bewertung und technische Umsetzung.';
    els.quizRun.hidden = true;
    els.quizResult.hidden = false;
    els.quizResult.innerHTML = `
      <div class="quiz-result-box">
        <span class="eyebrow">Training beendet</span>
        <div class="result-score">${score}/${total}</div>
        <h2>${score * 10} % richtig</h2>
        <p>${escapeHtml(message)}</p>
        <p><small>Persönlicher Bestwert: ${state.bestQuiz}/${total}</small></p>
        <div class="button-row">
          <button class="button button-primary" type="button" data-restart-quiz>Erneut trainieren</button>
          <a class="button button-secondary" href="#lernen" data-view-link="lernen">Lernmodule öffnen</a>
        </div>
      </div>`;
  }

  function resetProgress() {
    const confirmed = window.confirm('Lernstand, Lernplan und Quiz-Bestwert wirklich löschen?');
    if (!confirmed) return;
    const keepTheme = state.theme;
    state = { ...defaultState, theme: keepTheme };
    saveState();
    renderAll();
    showToast('Lernstand zurückgesetzt.');
  }

  function renderAll() {
    renderDashboard();
    renderModules();
    renderSchemaStep(0);
    renderTemplates();
    renderPlan();
    updateCalculator();
  }

  document.addEventListener('click', event => {
    const viewLink = event.target.closest('[data-view-link]');
    if (viewLink) {
      event.preventDefault();
      setView(viewLink.dataset.viewLink);
      return;
    }

    const topicButton = event.target.closest('[data-open-topic]');
    if (topicButton) {
      openTopic(topicButton.dataset.openTopic);
      return;
    }

    const areaButton = event.target.closest('[data-open-area]');
    if (areaButton) {
      activeArea = areaButton.dataset.openArea;
      els.filterChips.forEach(chip => chip.classList.toggle('is-active', chip.dataset.areaFilter === activeArea));
      renderModules();
      setView('lernen');
      return;
    }

    const completeInput = event.target.closest('[data-complete-topic]');
    if (completeInput) {
      toggleTopic(completeInput.dataset.completeTopic);
      return;
    }

    const dialogComplete = event.target.closest('[data-dialog-complete]');
    if (dialogComplete) {
      toggleTopic(dialogComplete.dataset.dialogComplete);
      showToast(state.completed.includes(dialogComplete.dataset.dialogComplete) ? 'Als gelernt markiert.' : 'Markierung entfernt.');
      return;
    }

    const copyButton = event.target.closest('[data-copy-template]');
    if (copyButton) {
      copyTemplate(Number(copyButton.dataset.copyTemplate));
      return;
    }

    const planInput = event.target.closest('[data-plan-index]');
    if (planInput) {
      togglePlan(Number(planInput.dataset.planIndex));
      return;
    }

    const quizChoice = event.target.closest('[data-quiz-choice]');
    if (quizChoice) {
      answerQuiz(Number(quizChoice.dataset.quizChoice));
      return;
    }

    if (event.target.closest('[data-restart-quiz]')) {
      startQuiz();
    }
  });

  els.filterChips.forEach(chip => {
    chip.addEventListener('click', () => {
      activeArea = chip.dataset.areaFilter;
      els.filterChips.forEach(item => item.classList.toggle('is-active', item === chip));
      renderModules();
    });
  });

  els.schemaTabs.forEach(tab => tab.addEventListener('click', () => renderSchemaStep(Number(tab.dataset.schemaStep))));

  els.globalSearch.addEventListener('input', event => {
    searchTerm = event.target.value;
    renderModules();
    if (searchTerm.trim().length >= 2) setView('lernen');
  });

  document.addEventListener('keydown', event => {
    if (event.key === '/' && !['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName)) {
      event.preventDefault();
      els.globalSearch.focus();
    }
  });

  els.themeToggle.addEventListener('click', () => {
    state.theme = els.html.dataset.theme === 'dark' ? 'light' : 'dark';
    saveState();
    applyTheme();
  });

  document.querySelectorAll('[data-exam]').forEach(tab => {
    tab.addEventListener('click', () => {
      if (tab.dataset.exam === '3') return;
      if (typeof els.placeholderDialog.showModal === 'function') els.placeholderDialog.showModal();
      else els.placeholderDialog.setAttribute('open', '');
    });
  });

  els.dialogClose.addEventListener('click', () => closeDialog(els.topicDialog));
  els.placeholderClose.addEventListener('click', () => closeDialog(els.placeholderDialog));
  els.placeholderOk.addEventListener('click', () => closeDialog(els.placeholderDialog));
  els.topicDialog.addEventListener('click', event => {
    if (event.target === els.topicDialog) closeDialog(els.topicDialog);
  });
  els.placeholderDialog.addEventListener('click', event => {
    if (event.target === els.placeholderDialog) closeDialog(els.placeholderDialog);
  });

  els.resetProgress.addEventListener('click', resetProgress);
  els.pointsInput.addEventListener('input', updateCalculator);
  els.startQuiz.addEventListener('click', startQuiz);
  els.nextQuestion.addEventListener('click', nextQuestion);

  window.addEventListener('hashchange', () => setView(location.hash.slice(1), false));

  applyTheme();
  renderAll();
  setView(location.hash.slice(1) || 'dashboard', false);
})();
